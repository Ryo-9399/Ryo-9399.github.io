﻿
●概要
　この度は、「JS版まさおコンストラクション」（Canvasまさお）をダウンロード
していただき、ありがとうございます。
　本ライブラリは福田直人氏の制作した「まさおコンストラクション」を、
挙動をそのままに、かつWebブラウザ上で動作するように、JavaScriptを用いて
移植したものです。また、原作と挙動を完全互換にすることにより、
自動系・裏技系も再現できるようにしました。

※本ライブラリはHTML5のAPIを使用しておりますので、古いブラウザでは
　動作しません。最新のブラウザでご使用ください。


●パッケージ内容
!ReadMe.txt
	本ファイルです。
_ソースコンバータ.html
	原作の、paramタグで構成されたステージデータを、JS版ソースに変換します
_ブックマークレット.html
	既存のまさおアプレットをJS版に変換するブックマークレットを記述しています。
_サンプルリスト.html
	フォルダ内のサンプルのリストを表示します。
game01.html ～ game15.html
	福田直人氏の制作したサンプルステージです。
CanvasMasao.js
	JS版まさおの本体です。


●起動方法
・JSまさお本体のJSファイルを読み込む。（ヘッダ内に記述するのが望ましい）
※この例は、JSファイルが同じディレクトリに存在する場合の記述です。
	<script type="text/javascript" src="CanvasMasao_v28.js"></script>
・この下にスクリプト<script type="text/javascript">～</script>を
記述し、中身を次のようにする。
	・属性id="myid"を持つアプレットをJS版に置換したい場合
		CanvasMasao.Game.replace( "myid" );
	・ページ内の全てのまさおアプレットを置換したい場合
		CanvasMasao.Game.replaceAll();
	・パラメータをスクリプトで記述して構築したい場合
		new CanvasMasao.Game( パラメータオブジェクト );
	・属性id="myid"を持つ要素の中に構築したい場合
		new CanvasMasao.Game( パラメータオブジェクト, "myid" );
ここで、パラメータオブジェクトは、パラメータのnameをキーとし、
valueを値とする連想配列です。

使用例１：特定IDを持つアプレットの置換
	<script …>
		CanvasMasao.Game.replace("applet1_id");
	</script>
	…
	<applet code="MasaoConstruction.class" id="applet1_id" …>
		<param name=… value=…> …
	</applet>

使用例２：ページ内の全てのまさおアプレットの置換
code属性に"MasaoConstruction"（大文字・小文字の区別なし）を含むもの、
そしてアプレットに該当するObject要素が置換対象です。
	<script …>
		CanvasMasao.Game.replaceAll();
	</script>
	…
	<applet code="MasaoConstruction.class" …>
	… </applet>
	<applet code="MasaoConstruction.class" …>
	… </applet>
	<applet code="MasaoConstruction.class" …>
	… </applet> …

使用例３：パラメータを渡して構築（実行した位置に構築される）
	<script …>
		new CanvasMasao.Game({
			"time_max": "500",
			"map0-0": "..........",
			…
		});
	</script>

使用例４：パラメータを渡して、特定IDを持つ要素の中へ構築
	<script …>
		new CanvasMasao.Game({
			…
		}, "masao_div");
	</script>
	…
	<div id="masao_div"></div>

＊replace()の第２引数、replaceAll()の第１引数、及び
コンストラクタCanvasMasao.Gameの第３引数にオブジェクトを追加すると、
まさおの起動オプションを指定できます。
以下に示す名前をキーとする連想配列を渡すと、それらが適用されます。
・width, height
	ゲーム画面の幅と高さ
	意図的に表示範囲を制限したステージの再現が可能となります。
・highscoreCallback
	ハイスコア更新時に実行するコールバック関数
	コールバック関数の第１引数にハイスコアが格納されます。

使用例５：ハイスコアイベントリスナを指定する（特定アプレット置換型）
	<script …>
		function handleHighscoreEvent(score)
		{
			// 送信する処理などをこの関数内に記述
			document.f.score.value = score;
		}
		CanvasMasao.Game.replace("applet1_id", {
			highscoreCallback : handleHighscoreEvent
		});
	</script>
	…
	<applet code="MasaoConstruction.class" id="applet1_id" …>
		<param name=… value=…> …
	</applet>
	…
	<form name="f" method="post">
		名前：<input type="text" name="name">
		得点：<input type="text" name="score" value="0" readonly>
		<input type="submit" value="送信">
	</form>

使用例６：ハイスコアイベントリスナを指定する（全アプレット置換型）
※全アプレットのイベントを取得するので非推奨（１つだけなら問題ない）
	<script …>
		function handleHighscoreEvent(score){ … }
		CanvasMasao.Game.replaceAll({
			highscoreCallback : handleHighscoreEvent
		});
	</script>
	…
	<applet code="MasaoConstruction.class" …>
	… </applet>
	<applet code="MasaoConstruction.class" …>
	… </applet>
	<applet code="MasaoConstruction.class" …>
	… </applet> …

使用例７：ハイスコアイベントリスナを指定する（構築型）
※特定IDを持つ要素の中へ構築したい場合は、第２引数にnullではなくIDを指定してください。
	<script …>
		function handleHighscoreEvent(score){ … }
		new CanvasMasao.Game({
			"time_max": "500",
			"map0-0": "..........",
			…
		}, null, {
			highscoreCallback : handleHighscoreEvent
		});
	</script>

使用例８：ハイスコアイベントリスナを無名関数にする
外部からの攻撃に少し強くなります。
	<script …>
		…(…
		{
			highscoreCallback : function (score){ … }
		});
	</script>

使用例８応用：ハイスコアイベントリスナにクロージャを使用する
外部からの攻撃にかなり強くなります。
	<script type="text/javascript">
		…(…
		{
			highscoreCallback : (function (){
				var score = 0;
				window.addEventListener("load",
					function (){
						document.f.addEventListener("submit",
							function (e){
								e.stopImmediatePropagation();
								document.f.score.value = score;
							}
						);
					}
				);
				return function (s){
					score = s;
					document.f.score_display.value = s;
				};
			})()
		});
	</script>
	…
	<form name="f" method="post">
		名前：<input type="text" name="name">
		得点：<input type="text" name="score_display" value="0" readonly>
		<input type="hidden" name="score" value="0">
		<input type="submit" value="送信">
	</form>

使用例９：ゲーム画面のサイズを変更する
	<script …>
		…(…
		{
			width : 128, height : 96
		});
	</script>


●ブックマークレットについて
既存のまさおアプレットをJS版に変換することができます。
リンクをブックマークして、まさおのページで使用すると、JS版に置き換えることができます。
最新版（バージョン２）でないと動作しないので注意してください。
（使用する際にインターネットに接続して外部JSファイルを参照するので、
　インターネットに接続しないと動作しないので注意してください）


●連絡先・注意事項
　バグ報告やご意見、ご要望は、下記まで連絡をお願いします。
E-mail: ryo19950926@gmail.com


　また、GitHubにソースを公開しておりますので、開発に
ご協力いただける方を募集しています。
https://github.com/Ryo-9399/mc_canvas

　このプログラムは、あくまでも福田直人氏の「まさおコンストラクション」の
Javaプログラムを解析し、JavaScript用に変換しただけのものです。したがって、
プログラムの著作権は福田直人氏が保有します。
